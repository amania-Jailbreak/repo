import os
import shutil
import urllib.request
import os
import spotipy
import spotipy.oauth2 as oauth2
from youtube_search import YoutubeSearch


def write_tracks(text_file: str, tracks: dict):
    # Writes the information of all tracks in the playlist to a text file. 
    # This includins the name, artist, and spotify URL. Each is delimited by a comma.
    with open(text_file, 'w+', encoding='utf-8') as file_out:
        while True:
            for item in tracks['items']:
                if 'track' in item:
                    track = item['track']
                else:
                    track = item
                try:
                    track_url = track['external_urls']['spotify']
                    track_name = track['name']
                    track_artist = track['artists'][0]['name']
                    csv_line = track_name + "," + track_artist + "," + track_url + "\n"
                    try:
                        file_out.write(csv_line)
                    except UnicodeEncodeError:  # Most likely caused by non-English song names
                        print("Track named {} failed due to an encoding error. This is \
                            most likely due to this song having a non-English name.".format(track_name))
                except KeyError:
                    print(u'Skipping track {0} by {1} (local only?)'.format(
                            track['name'], track['artists'][0]['name']))
            # 1 page = 50 results, check if there are more pages
            if tracks['next']:
                tracks = spotify.next(tracks)
            else:
                break


def write_playlist(username: str, playlist_id: str):
    results = spotify.user_playlist(username, playlist_id, fields='tracks,next,name')
    playlist_name = results['name']
    text_file = u'{0}.txt'.format(playlist_name, ok='-_()[]{}')
    print(u'Writing {0} tracks to {1}.'.format(results['tracks']['total'], text_file))
    tracks = results['tracks']
    write_tracks(text_file, tracks)
    return playlist_name


def find_and_download_songs(reference_file: str):
    TOTAL_ATTEMPTS = 10
    with open(reference_file, "r", encoding='utf-8') as file:
        for line in file:
            temp = line.split(",")
            name, artist = temp[0], temp[1]
            text_to_search = artist + " - " + name
            best_url = None
            attempts_left = TOTAL_ATTEMPTS
            while attempts_left > 0:
                try:
                    results_list = YoutubeSearch(text_to_search, max_results=1).to_dict()
                    best_url = "https://www.youtube.com{}".format(results_list[0]['url_suffix'])
                    break
                except IndexError:
                    attempts_left -= 1
                    print("No valid URLs found for {}, trying again ({} attempts left).".format(
                        text_to_search, attempts_left))
            if best_url is None:
                print("No valid URLs found for {}, skipping track.".format(text_to_search))
                continue
            # Run you-get to fetch and download the link's audio
            print("Initiating download for {}.".format(text_to_search))
            os.system(f"dir && youtube-dl -i --extract-audio --embed-thumbnail --audio-format mp3 --audio-quality 0 {best_url}")

print("Loading")
if shutil.which('ffmpeg') == None:
    print("Error: ffmpeg is not installed If you get an error, reboot a few times and try again.")
    exit("-1")
if shutil.which('youtube-dl') == None:
    print("Error: youtube-dl is not installed If you get an error, reboot a few times and try again.")
    exit("-1")
os.system("youtube-dl --version")
print("""If the version of Youtube-DL is not shown and you get an error, delete and restart Youtube-dl.exe or replace it with youtube-dl.exe from Electube's Github page.
Electube IOS
[1]Audio Download
[2]Video Download
[3]Spotify PlayList Download
[b] Beta""")
cmd = input(">>")
if cmd == "1":
    url = input("url>>")
    os.system(f"youtube-dl -i --extract-audio --embed-thumbnail --audio-format mp3 --audio-quality 0 {url}")
elif cmd == "2":
    url = input("url>>")
    os.system(f"youtube-dl --format mp4 --add-metadata {url}")
elif cmd == "b":
    print("""--------------Beta------------------
    No Beta features currently available""")
elif cmd == "3":
    client_id = "9a71a4a88f5d4812aabdca88f8b58eeb"
    client_secret = "85a8d521902e4088a4ffe4463d3d854b"
    username = "amania"
    playlist_uri = input("Playlist URI: ")
    auth_manager = oauth2.SpotifyClientCredentials(client_id=client_id, client_secret=client_secret)
    spotify = spotipy.Spotify(auth_manager=auth_manager)
    playlist_name = write_playlist(username, playlist_uri)
    reference_file = "{}.txt".format(playlist_name)
    find_and_download_songs(reference_file)
    print("Operation complete.")

input("[Processing is finished]")

